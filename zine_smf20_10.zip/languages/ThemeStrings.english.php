<?php

/* @ Zine theme */
/*	@ Blocthemes 2020	*/
/*	@	SMF 2.0.x	*/

$txt['a_unread'] = 'Unread';
$txt['a_replies'] = 'Replies';
$txt['a_options'] = 'Options';
$txt['a_maintain'] = 'Maintenance';

$txt['a_boardindex'] = 'Boards';
$txt['a_infocenter'] = 'Info Center';
$txt['a_maside'] = 'Information';
$txt['a_category'] = 'Category';
$txt['a_categories'] = 'Categories';

$txt['a_messages'] = 'Messages';
$txt['a_poll'] = 'Poll';
$txt['a_calendar_linked_events'] = 'Calendar';

$txt['a_news'] = 'Latest News';
$txt['a_nonews'] = 'At this time there are no news.';

$txt['a_new_posts'] = 'Go to new posts';

$txt['a_change'] = 'change';
$txt['mark_cat_as_read'] = 'Mark category as read';

$txt['a_moverecent'] = 'Show recent posts(if applicable) under category list';

?>
